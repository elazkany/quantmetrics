def squared(number):
    return number ** 2